#include "Scene.h"
#include "Sphere.h"
#include "Texture.h"

namespace actracer {

Sphere::Sphere(int _id, Material *_mat, float _radius, const Vector3f &centerPoint, Transform *objToWorld, ShadingMode shMode)
    : Shape(_id, _mat, objToWorld, shMode), radius(_radius), center(centerPoint)
{
    shType = ShapeType::SPHERE;

    if (objTransform)
        objTransform->UpdateTransform();
        
    this->orgBbox = BoundingVolume3f(centerPoint + Vector3f(-radius, -radius, -radius), centerPoint + Vector3f(radius, radius, radius));

    if(this->objTransform)
        this->bbox = (*objTransform)(this->orgBbox);
    else
        this->bbox = this->orgBbox;

    // this->bbox = this->orgBbox;
}


Vector3f Sphere::RegulateNormal(Vector3f textureNormal, SurfaceIntersection &intersection)
{
    float phi = intersection.lip.y, theta = intersection.lip.x; 
    float u = intersection.uv.u;
    float v = intersection.uv.v;

    float x = radius * std::sin(v * PI) * std::cos(PI - u * 2 * PI);
    float y = radius * std::cos(v * PI);
    float z = radius * std::sin(v * PI) * std::sin(PI - u * 2 * PI);

    // float x = radius * std::sin(v * 3.14f) * std::cos(3.14f - u * 6.18f);
    // float y = radius * std::sin(intersection.lip.x);
    // float z = radius * std::sin(v * 3.14f) * std::sin(3.14f - u * 6.18f);

    float dpxu = z * 2 * PI;
    float dpyu = 0.0f;
    float dpzu = -1 * x * 2 * PI;

    float dpxv = y * std::cos(phi) * PI;
    float dpyv = -1 * radius * std::sin(theta) * PI;
    float dpzv = y * std::sin(phi) * PI;

    glm::vec3 T = Normalize(Vector3f(dpxu, dpyu, dpzu));
    glm::vec3 B = Normalize(Vector3f(dpxv, dpyv, dpzv));

    // T = Normalize(Vector3f(-1 * radius * std::cos(intersection.lip.x) * std::sin(intersection.lip.y), 0.0f, radius * std::cos(intersection.lip.x) * std::cos(intersection.lip.y)));
    // T = Normalize(Vector3f(-1 * std::sin(phi), 0.0f, std::cos(phi)));

    // B = Normalize(Cross(intersection.n, (Vector3f)T));



    glm::vec3 N(intersection.n.x, intersection.n.y, intersection.n.z);



    T = T - N * glm::dot(T, N);
    B = B - glm::dot(B, N) * N - glm::dot(T, B) * T;

    glm::mat3x3 lastRegul(T, B, N);

    Vector3f res = lastRegul * textureNormal;

    res = Normalize(res);

    return res;
}

Vector3f Sphere::GetBumpedNormal(Texture *tex, SurfaceIntersection &intersection, Ray &ray)
{
    float phi = intersection.lip.y, theta = intersection.lip.x;
    float u = intersection.uv.u;
    float v = intersection.uv.v;

    float x = radius * std::sin(v * PI) * std::cos(PI - u * 2 * PI);
    float y = radius * std::cos(v * PI);
    float z = radius * std::sin(v * PI) * std::sin(PI - u * 2 * PI);

    // float x = radius * std::sin(v * 3.14f) * std::cos(3.14f - u * 6.18f);
    // float y = radius * std::sin(intersection.lip.x);
    // float z = radius * std::sin(v * 3.14f) * std::sin(3.14f - u * 6.18f);

    float dpxu = z * 2 * PI;
    float dpyu = 0.0f;
    float dpzu = -1 * x * 2 * PI;

    float dpxv = y * std::cos(phi) * PI;
    float dpyv = -1 * radius * std::sin(theta) * PI;
    float dpzv = y * std::sin(phi) * PI;

    glm::vec3 T = Normalize(Vector3f(dpxu, dpyu, dpzu));
    glm::vec3 B = Normalize(Vector3f(dpxv, dpyv, dpzv));

    // T = Normalize(Vector3f(-1 * radius * std::cos(intersection.lip.x) * std::sin(intersection.lip.y), 0.0f, radius * std::cos(intersection.lip.x) * std::cos(intersection.lip.y)));
    // T = Normalize(Vector3f(-1 * std::sin(phi), 0.0f, std::cos(phi)));

    // B = Normalize(Cross(intersection.n, (Vector3f)T));

    glm::vec3 N(intersection.n.x, intersection.n.y, intersection.n.z);

    T = T - N * glm::dot(T, N);
    B = B - glm::dot(B, N) * N - glm::dot(T, B) * T;

    u -= std::floor(u);
    v -= std::floor(v);

    float epsilon = 0.002f;

    int i = round(u * (tex->width - 1));
    int j = round(v * (tex->height - 1));
    

    Vector3f col = tex->RetrieveRGBFromUV(u, v);
    Vector3f hCol = tex->RetrieveRGBFromUV(u + epsilon, v);
    Vector3f vCol = tex->RetrieveRGBFromUV(u, v + epsilon);

    // col = tex->Fetch(i, j);
    // hCol = tex->Fetch(i + 1, j);
    // vCol = tex->Fetch(i, j + 1);

    float sc = (col.x + col.y + col.z) / 3;
    float hc = (hCol.x + hCol.y + hCol.z) / 3;
    float vc = (vCol.x + vCol.y + vCol.z) / 3;

    float diff1 = (hc - sc);
    float diff2 = (vc - sc);

    // std::cout << diff1 << " " << diff2 << "\n";

    glm::vec3 resn = N - T * diff1 - B * diff2;

    resn = glm::normalize(resn);

    if(glm::dot(resn, N) < 0)
        resn *= -1;

    Vector3f nn(resn.x, resn.y, resn.z);

    return nn;

    // Vector2f uv(intersection.uv);
    // Vector3f point(intersection.ip);
    // float phi, theta;

    // theta = std::acos((point.y - center.y) / radius);
    // phi = std::atan2((point.z - center.z), (point.x - center.x));

    // Vector3f worldCenteredPosition = point - center;
    // worldCenteredPosition = (*this->objTransform)(worldCenteredPosition, true);

    // theta = std::acos(worldCenteredPosition.y / radius);
    // phi = std::atan2(worldCenteredPosition.z, worldCenteredPosition.x);

    // uv.x = (-phi + PI) / 2 * PI;
    // uv.y = theta / PI;

    // theta = uv.y * PI;
    // phi = PI - 2 * PI * uv.x;

    // float x = radius * std::sin(theta) * std::cos(phi);
    // float y = radius * std::cos(theta);
    // float z = radius * std::sin(theta) * std::sin(phi);

    // Vector3f pu{};
    // pu.x = 2 * PI * z;
    // pu.y = 0.0f;
    // pu.z = -2 * PI * x;

    // Vector3f pv{};
    // pv.x = PI * y * std::cos(phi);
    // pv.y = -PI * radius * std::sin(theta);
    // pv.z = PI * y * std::sin(phi);

    // return tex->GetBumpNormal(intersection.n, intersection.uv.x, intersection.uv.y, pu, pv);

    // float phi = intersection.lip.y, theta = intersection.lip.x;
    // float u = intersection.uv.u;
    // float v = intersection.uv.v;

    // float x = radius * std::sin(v * 3.14f) * std::cos(3.14f - u * 6.18f);
    // float y = radius * std::cos(v * 3.14f);
    // float z = radius * std::sin(v * 3.14f) * std::sin(3.14f - u * 6.18f);

    // // float x = radius * std::sin(v * 3.14f) * std::cos(3.14f - u * 6.18f);
    // // float y = radius * std::sin(intersection.lip.x);
    // // float z = radius * std::sin(v * 3.14f) * std::sin(3.14f - u * 6.18f);

    // float dpxu = z * 6.18f;
    // float dpyu = 0.0f;
    // float dpzu = -1 * x * 6.18f;

    // float dpxv = y * std::cos(phi) * 3.14f;
    // float dpyv = -1 * radius * std::sin(theta) * 3.14f;
    // float dpzv = y * std::sin(phi) * 3.14f;

    // Vector3f T = Vector3f(dpxu, dpyu, dpzu);
    // Vector3f B = Vector3f(dpxv, dpyv, dpzv);

    // Vector3f diff1 = (tex->GetHorizontalDifference(intersection.uv.x, intersection.uv.y)) * tex->bumpFactor;
    // Vector3f diff2 = (tex->GetVerticalDifference(intersection.uv.x, intersection.uv.y)) * tex->bumpFactor;

    // Vector3f rsn = Normalize(Cross((Vector3f)T, (Vector3f)B));
    // if (Dot(rsn, intersection.n) < 0)
    //     rsn *= -1;

    // Vector3f qu = (Vector3f)T + diff1.x * intersection.n;
    // Vector3f qv = (Vector3f)B + diff2.y * intersection.n;

    // Vector3f ress = Normalize(Cross(qu, qv));

    // if (Dot(ress, intersection.n) < 0)
    //     ress *= -1;

    // int i1 = MaxAbsElementIndex(diff1);
    // int i2 = MaxAbsElementIndex(diff2);

    // // diff1.x = diff1.y = diff1.z = diff1[i1];
    // // diff2.x = diff2.y = diff2.z = diff2[i2];

    // T = Normalize(T);
    // B = Normalize(B);

    // Vector3f N = Cross(T, B);

    

    // if (Dot(N, intersection.n) < 0)
    // {
    //     Vector3f temp = T;
    //     T = B;
    //     B = T;

    //     N = Normalize(Cross(T, B));
    // }

    // T = T - N * Dot(T, N);
    // B = B - Dot(B, N) * N - Dot(T, B) * T;

    // Vector3f self = tex->GetPixelOffset(u, v, 0, 0);
    // Vector3f north = tex->GetPixelOffset(u, v, 0, 1);
    // Vector3f south = tex->GetPixelOffset(u, v, 0, -1);
    // Vector3f east = tex->GetPixelOffset(u, v, 1, 0);
    // Vector3f west = tex->GetPixelOffset(u, v, -1, 0);

    // float col = (self.x + self.y + self.z) / 3.0f;
    // self.x = self.y = self.z = col;

    // col = (north.x + north.y + north.z) / 3.0f;
    // north.x = north.y = north.z = col;

    // col = (south.x + south.y + south.z) / 3.0f;
    // south.x = south.y = south.z = col;

    // col = (east.x + east.y + east.z) / 3.0f;
    // east.x = east.y = east.z = col;

    // col = (west.x + west.y + west.z) / 3.0f;
    // west.x = west.y = west.z = col;

    // Vector3f hr = tex->GetHorizontalDifference(u, v);
    // Vector3f vr = tex->GetVerticalDifference(u, v);

    // //std::cout << self << " " << north << " " << south << " " << east << " " << west << "\n";
    
    // // T = T - N * Dot(T, N);
    // // B = B - Dot(B, N) * N - Dot(T, B) * T;

    // float horzDiff = (east.x - west.x) * tex->bumpFactor;
    // float vertDiff = (north.x - south.x) * tex->bumpFactor;

    // Vector3f qpru = T + horzDiff * N;
    // Vector3f qprv = B + vertDiff * N;



    // Vector3f nres = Normalize(Cross(qpru, qprv));

    // nres = N - horzDiff * T - vertDiff * B;

    // if (Dot(nres, N) < 0)
    //     nres *= -1;

    // return nres;

    // Vector3f f1 = ((diff1.x + diff1.y + diff1.z) / 3) * (Vector3f)T;
    // Vector3f f2 = ((diff2.x + diff2.y + diff2.z) / 3) * (Vector3f)B;

    // f1 = f1;
    // f2 = f2;

    // rsn = intersection.n;

    // // rsn = Cross((Vector3f)T, (Vector3f)B);

    // Vector3f nn = rsn - f1 - f2;


    // return nn;
}

void Sphere::Intersect(Ray &rr, SurfaceIntersection &rt)
{
    // x - c.x  y - c.y z - c.z = r
    // s + tv
    // (s.x + tv.x - c.x)
    // s.x ^ 2 + t ^ 2 * v.x ^ 2 + 2 * s.x tv.x + c.x ^ 2 - 2 * c.x * s.x - c.x * t * v.x
    // t ^ 2 * s.x ^ 2 * v.x ^ 2
    // 2 * s.x * t * v.x = c.x * t * v.x
    Ray r = rr;

    if (this->objTransform)
        ApplyTransformationToRay(r);

    Vector3f originToCenter = r.o - center; // Direction vector pointing from sphere's center to ray's origin

    float dirOtC = Dot(originToCenter, r.d); // Correlation between ray direction and ray from center to origin
    float dd = Dot(r.d, r.d);                // Direction ^ 2

    // Discriminant of the quadratic sphere equation
    float discriminant = dirOtC * dirOtC - dd * (Dot(originToCenter, originToCenter) - radius * radius);

    // sqrt(< 0) -> nan
    if (discriminant < 0)
        return; // Return default no intersection

    // Calculate closer intersection point
    discriminant = std::sqrt(discriminant);
    float t = -1 * dirOtC - discriminant;

    if (t < 0 || ((-dirOtC + discriminant) < t && -dirOtC + discriminant > 0))
        t = -1 * dirOtC + discriminant;

    float ot = t / dd;

    if (ot > 0) // If there is an intersection
    {
        Transform trr = *this->objTransform;



        Vector3f point = r(ot);                  // intersection point
        Vector3f no = (point - center) / radius; // surface normal

        Vector2f uv{};

        float phi, theta;

        theta = std::acos((point.y - center.y) / radius);
        phi = std::atan2((point.z - center.z), (point.x - center.x));

        uv.x = (-phi + PI) / (2 * PI);
        uv.y = theta / PI;


        Vector3f worldCenteredPosition = point - center;
        worldCenteredPosition = (*this->objTransform)(worldCenteredPosition, true);

        theta = std::acos(worldCenteredPosition.y / radius);
        phi = std::atan2(worldCenteredPosition.z, worldCenteredPosition.x);

        


        // uv.x -= std::floor(uv.x);
        // uv.y -= std::floor(uv.y);

        theta = uv.y * PI;
        phi = PI - (2 * PI) * uv.x;

        // point = (trr)(Vector4f(point, 1.0f), true);
        // no = (trr)(Vector4f(no, 0.0f), true, true);
        // no = Normalize(no);

        if(false && this->textures[1])
        {
            // float x = radius * std::sin(v * 3.14f) * std::cos(3.14f - u * 6.18f);
            // float y = radius * std::cos(v * 3.14f);
            // float z = radius * std::sin(v * 3.14f) * std::sin(3.14f - u * 6.18f);

            // // float x = radius * std::sin(v * 3.14f) * std::cos(3.14f - u * 6.18f);
            // // float y = radius * std::sin(intersection.lip.x);
            // // float z = radius * std::sin(v * 3.14f) * std::sin(3.14f - u * 6.18f);

            // float dpxu = z * 6.18f;
            // float dpyu = 0.0f;
            // float dpzu = -1 * x * 6.18f;

            // float dpxv = y * std::cos(phi) * 3.14f;
            // float dpyv = -1 * radius * std::sin(theta) * 3.14f;
            // float dpzv = y * std::sin(phi) * 3.14f;

            // Vector3f T = Vector3f(dpxu, dpyu, dpzu);
            // Vector3f B = Vector3f(dpxv, dpyv, dpzv);

            float x = radius * std::sin(theta) * std::cos(phi);
            float y = radius * std::cos(theta);
            float z = radius * std::sin(theta) * std::sin(phi);

            

            Vector3f pu{};
            pu.x = 6.28f * z;
            pu.y = 0.0f;
            pu.z = -6.28f * x;

            Vector3f pv{};
            pv.x = 3.14f * y * std::cos(phi);
            pv.y = -3.14f * radius * std::sin(theta);
            pv.z = 3.14f * y * std::sin(phi);
            
            no = this->textures[1]->GetBumpNormal(no, uv.x, uv.y, pu, pv);
        }
        // std::cout << point.y << " " << radius << "\n";

        

        if (this->motionBlur.x != 0 || this->motionBlur.y != 0 || this->motionBlur.z != 0)
        {
            Vector3f motBlurToRay = this->motionBlur * r.time;
            Transformation tr = Translation(-1, (glm::vec3)motBlurToRay);
            trr = (*this->objTransform)(tr);
            trr.UpdateTransform();
        }
        Vector3f lip = point;
        point = (trr)(Vector4f(point, 1.0f), true);
        no = (trr)(Vector4f(no, 0.0f), true, true);
        no = Normalize(no);

        ot = rr(point);

        rt = SurfaceIntersection(Vector3f{theta, phi, 0.0f}, point, no, uv, originToCenter, ot, mat, (Shape*)this, textures[0], textures[1]);
    }
}

Shape *Sphere::Clone(bool resetTransform) const
{
    Sphere* cloned = new Sphere{};

    cloned->id = this->id;
    cloned->mat = this->mat;
    cloned->orgBbox = this->orgBbox;

    for (Texture *t : this->textures)
        cloned->textures.push_back(t);

    if (!resetTransform)
    {
        cloned->bbox = this->bbox;
        Transform *newTransformation = new Transform(*(this->objTransform));
        cloned->objTransform = newTransformation;
    }
    else
    {
        cloned->bbox = this->bbox;
        glm::mat4 dummy = glm::mat4(1);
        cloned->objTransform = new Transform{dummy};
    }

    cloned->radius = this->radius;
    cloned->center = this->center;

    return cloned;
}

}