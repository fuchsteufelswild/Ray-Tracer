#include "Scene.h"
#include "Triangle.h"
#include "Texture.h"

namespace actracer {

Triangle::Triangle(int _id, Material *_mat, const Vector3f &p0, const Vector3f &p1, const Vector3f &p2,
                   const Vector2f& uv0, const Vector2f& uv1, const Vector2f& uv2,
                   Transform *objToWorld, Shape *_m, ShadingMode shMode)
    : Shape(_id, _mat, objToWorld, shMode)
{
    ownerMesh = _m;
    shType = ShapeType::TRIANGLE;

    if(!_m && objTransform)
        objTransform->UpdateTransform();


    if(!_m)
        ownerMesh = (Shape*)this;

    v0 = new Vertex{};
    v1 = new Vertex{};
    v2 = new Vertex{};

    v0->p = p0;
    v1->p = p1;
    v2->p = p2;

    v0->uv = uv0;
    v1->uv = uv1;
    v2->uv = uv2;

    p0p1 = p0 - p1;
    p0p2 = p0 - p2;

    normal = Normalize(Cross(-p0p1, -p0p2));

    this->orgBbox = BoundingVolume3f(MaxElements(p0, MaxElements(p1, p2)),
                                     MinElements(p0, MinElements(p1, p2)));

    if(this->objTransform)
        this->bbox = (*objTransform)(this->orgBbox);
    else
        this->bbox = this->orgBbox;
}

Triangle::Triangle(int _id, Material *_mat, Vertex *p0, Vertex *p1, Vertex* p2, Transform *objToWorld, Shape *_m, ShadingMode shMode)
    : Shape(_id, _mat, objToWorld, shMode)
{
    ownerMesh = _m;
    shType = ShapeType::TRIANGLE;

    if (!_m && objTransform)
        objTransform->UpdateTransform();

    if (!_m)
        ownerMesh = (Shape *)this;

    v0 = p0;
    v1 = p1;
    v2 = p2;

    p0p1 = p0->p - p1->p;
    p0p2 = p0->p - p2->p;

    surfaceArea = Length(Cross(-p0p1, -p0p2));
    normal = Normalize(Cross(-p0p1, -p0p2));

    Vector2f duv02 = p0->uv - p2->uv;
    Vector2f duv12 = p1->uv - p2->uv;

    Vector3f dp02 = p0->p - p2->p;
    Vector3f dp12 = p1->p - p2->p;

    float det = duv02[0] * duv12[1] - duv02[1] * duv12[0];






    this->orgBbox = BoundingVolume3f(MaxElements(p0->p, MaxElements(p1->p, p2->p)),
                                     MinElements(p0->p, MinElements(p1->p, p2->p)));

    if (this->objTransform)
        this->bbox = (*objTransform)(this->orgBbox);
    else
        this->bbox = this->orgBbox;

}

void Triangle::PerformVertexModification()
{
    // this->v0->n += this->normal * this->surfaceArea;
    // this->v0->refCount += this->surfaceArea;
    // this->v1->n += this->normal * this->surfaceArea;
    // this->v1->refCount += this->surfaceArea;
    // this->v2->n += this->normal * this->surfaceArea;
    // this->v2->refCount += this->surfaceArea;

    this->v0->n += this->normal;
    this->v0->refCount++;
    this->v1->n += this->normal;
    this->v1->refCount++;
    this->v2->n += this->normal;
    this->v2->refCount++;
}

void Triangle::RegulateVertices()
{
    if(this->v0->refCount != 0)
    {
        //this->v0->n /= this->v0->refCount;
        this->v0->n = Normalize(this->v0->n);
        this->v0->refCount = 0;
    }
    if (this->v1->refCount != 0)
    {
        //this->v1->n /= this->v1->refCount;
        this->v1->n = Normalize(this->v1->n);
        this->v1->refCount = 0;
    }
    if (this->v2->refCount != 0)
    {
        // this->v2->n /= this->v2->refCount;
        this->v2->n = Normalize(this->v2->n);
        this->v2->refCount = 0;
    }
}

bool SolveSystem(float A[2][2], float B[2], float* x0, float* x1)
{
    float det = A[0][0] * A[1][1] - A[0][1] * A[1][0];
    if (std::abs(det) < 1e-10f)
        return false;
    *x0 = (A[1][1] * B[0] - A[0][1] * B[1]) / det;
    *x1 = (A[0][0] * B[1] - A[1][0] * B[0]) / det;
    if (std::isnan(*x0) || std::isnan(*x1))
        return false;
    return true;
}

Vector3f Triangle::GetBumpedNormal(Texture* tex, SurfaceIntersection& intersection, Ray& ray)
{
    float u = intersection.uv.x;
    float v = intersection.uv.y;

    Vector3f p0p1t = (*this->objTransform)(-p0p1, true);
    Vector3f p0p2t = (*this->objTransform)(-p0p2, true);

    glm::vec3 e1 = -p0p1;
    glm::vec3 e2 = -p0p2;

    e1 = p0p1t;
    e2 = p0p2t;

    glm::mat3x2 E(glm::vec2(e1.x, e2.x), glm::vec2(e1.y, e2.y), glm::vec2(e1.z, e2.z));

    glm::vec2 a1 = glm::vec2(this->v0->uv.u - this->v1->uv.u, this->v0->uv.v - this->v1->uv.v);
    glm::vec2 a2 = glm::vec2(this->v0->uv.u - this->v2->uv.u, this->v0->uv.v - this->v2->uv.v);

    a1 *= -1;
    a2 *= -1;
    
    glm::mat2x2 A(glm::vec2(a1.x, a2.x), glm::vec2(a1.y, a2.y));

    A = glm::inverse(A);

    glm::mat3x2 soughtMat = A * E;

    glm::vec2 rr1 = soughtMat[0];
    glm::vec2 rr2 = soughtMat[1];
    glm::vec2 rr3 = soughtMat[2];

    glm::vec3 T = Normalize(Vector3f(rr1.x, rr2.x, rr3.x));
    glm::vec3 B = Normalize(Vector3f(rr1.y, rr2.y, rr3.y));

    glm::vec3 N = glm::cross(T, B);

    T = T - N * glm::dot(T, N);
    B = B - glm::dot(B, N) * N - glm::dot(T, B) * T;

    u -= std::floor(u);
    v -= std::floor(v);

    int i = round(u * (tex->width - 1));
    int j = round(v * (tex->height - 1));

    float epsilon = 0.001f;
    

    // col = tex->Fetch(i, j);
    // hCol = tex->Fetch(i + 1, j);
    // vCol = tex->Fetch(i, j + 1);
    // Vector3f n(N.x, N.y, N.z);
    // Vector3f p(intersection.ip.x, intersection.ip.y, intersection.ip.z);

    // float d = -Dot(n, Vector3f(p.x, p.y, p.z));
    // float tx = (-Dot(n, Vector3f(ray.rxo)) - d) /
    //            Dot(n, ray.rxd);
    // Vector3f px = ray.rxo + tx * ray.rxd;
    // float ty = (-Dot(n, Vector3f(ray.ryo)) - d) /
    //            Dot(n, ray.ryd);
    // Vector3f py = ray.ryo + ty * ray.ryd;

    // Vector3f dpdx = px - p;
    // Vector3f dpdy = py - p;

    // float dudx;
    // float dudy;

    // float dvdx;
    // float dvdy;

    // int dim[2];
    // if(std::abs(N.x) > std::abs(N.y) && std::abs(N.x) > std::abs(N.z)){
    //     dim[0] = 1; dim[1] = 2;}
    // else if(std::abs(N.y) > std::abs(N.z)){
    //     dim[0] = 0; dim[1] = 2;}
    // else {
    //     dim[0] = 0; dim[1] = 1;
    // }

    // float AA[2][2] = { {T[dim[0]], B[dim[0]]}, {T[dim[1]], B[dim[1]]}};
    // float Bx[2] = {px[dim[0]] - p[dim[0]], px[dim[1]] - p[dim[1]]};
    // float By[2] = {py[dim[0]] - p[dim[0]], py[dim[1]] - p[dim[1]]};

    // if (!SolveSystem(AA, Bx, &dudx, &dvdx))
    //     dudx = dvdx = 0;
    // if (!SolveSystem(AA, By, &dudy, &dvdy))
    //     dudy = dvdy = 0;

    // float dv = .5f * (std::abs(dvdx) + std::abs(dvdy));
    // if (dv == 0)
    //     dv = .01f;

    // float du = .5f * (std::abs(dudx) + std::abs(dudy));
    // if (du == 0)
    //     du = .01f;

    Vector3f col = tex->RetrieveRGBFromUV(u, v)       / 255 * tex->bumpFactor;
    Vector3f hCol = tex->RetrieveRGBFromUV(u + epsilon, v) / 255 * tex->bumpFactor;
    Vector3f vCol = tex->RetrieveRGBFromUV(u, v + epsilon) / 255 * tex->bumpFactor;

    float sc = (col.x + col.y + col.z) / 3;
    float hc = (hCol.x + hCol.y + hCol.z) / 3;
    float vc = (vCol.x + vCol.y + vCol.z) / 3;

    glm::vec3 dpdu = T + (hc - sc) * N;
    glm::vec3 dpdv = B + (vc - sc) * N;

    glm::vec3 resss = glm::cross(dpdu, dpdv);

    Vector3f nnn(resss.x, resss.y, resss.z);

    return nnn;
    


    glm::vec3 resn = N + (hc - sc) * glm::cross(N, B) - (vc - sc) * glm::cross(N, T);

    if (glm::dot(resn, N) < 0)
        resn *= -1;

    Vector3f nn(resn.x, resn.y, resn.z);

    return nn;

    float diff1 = ((hc / 255 - sc / 255) / epsilon) * tex->bumpFactor;
    float diff2 = ((vc / 255 - sc / 255) / epsilon) * tex->bumpFactor;

    resn = N - T * diff1 - B * diff2;

    resn = glm::cross(T + diff1 * N, B + diff2 * N);

    resn = glm::normalize(resn);

    if(glm::dot(resn, N) < 0)
        resn *= -1;

    nn = Vector3f(resn.x, resn.y, resn.z);

    return nn;

    // std::cout << "old vals: \n" << T;
    // std::cout << B;

    // Vector2f vduv02 = v0->uv - v2->uv;
    // Vector2f vduv12 = v1->uv - v2->uv;

    // Vector3f vdp02 = v0->p - v2->p;
    // Vector3f vdp12 = v1->p - v2->p;

    // if(vduv02[0] * vduv12[1] - vduv02[1] * vduv12[0] == 0)
    // {
    //     if(std::abs(normal.x) > std::abs(normal.y))
    //     {
    //         T = Vector3f(-normal.z, 0.0f, normal.x) / std::sqrt(normal.x * normal.x + normal.z * normal.z);
    //     }
    //     else
    //     {
    //         T = Vector3f(0.0f, normal.z, -normal.y) / std::sqrt(normal.y * normal.y + normal.z * normal.z);
    //     }

    //     B = Cross(normal, T);
    // }
    // else
    // {

    //     A = glm::mat2x2(glm::vec2(vduv02.x, vduv12.x), glm::vec2(vduv02.y, vduv12.y));
    //     A = glm::inverse(A);

    //     glm::mat3x2 P(glm::vec2(vdp02.x, vdp12.x), glm::vec2(vdp02.y, vdp12.y), glm::vec2(vdp02.z, vdp12.z));

    //     soughtMat = A * P;

    //     T = Vector3f(soughtMat[0].x, soughtMat[1].x, soughtMat[2].x);
    //     B = Vector3f(soughtMat[0].y, soughtMat[1].y, soughtMat[2].y);
    // }

    // T = T;
    // B = B;

    // // std::cout << "New vals: \n";
    // // std::cout << T << B;
    // // system("pause");

    // Vector3f self = tex->GetPixelOffset(u, v, 0, 0);
    // Vector3f north = tex->GetPixelOffset(u, v, 0, 1);
    // Vector3f south = tex->GetPixelOffset(u, v, 0, -1);
    // Vector3f east = tex->GetPixelOffset(u, v, 1, 0);
    // Vector3f west = tex->GetPixelOffset(u, v, -1, 0);

    // float col = (self.x + self.y + self.z) / 3.0f;
    // self.x = self.y = self.z = col;

    // col = (north.x + north.y + north.z) / 3.0f;
    // north.x = north.y = north.z = col;

    // col = (south.x + south.y + south.z) / 3.0f;
    // south.x = south.y = south.z = col;

    // col = (east.x + east.y + east.z) / 3.0f;
    // east.x = east.y = east.z = col;

    // col = (west.x + west.y + west.z) / 3.0f;
    // west.x = west.y = west.z = col;

    // Vector3f hr = tex->GetHorizontalDifference(u, v);
    // Vector3f vr = tex->GetVerticalDifference(u, v);


    // T = T;
    // B = B;

    // //std::cout << self << " " << north << " " << south << " " << east << " " << west << "\n";
    // Vector3f N = Normalize(Cross(T, B));

    // if(Dot(N, intersection.n) < 0)
    // {
    //     N = Normalize(Cross(B, T));
    //     Vector3f temp = T;
    //     T = B;
    //     B = temp;
    // }
    // // N = intersection.n;

    // T = T - N * Dot(T, N);
    // B = B - Dot(B, N) * N - Dot(T, B) * T;

    // T = T;
    // B = B;

    // float horzDiff = (east.x - self.x) * tex->bumpFactor;
    // float vertDiff = (north.x - self.x) * tex->bumpFactor;

    // return Normalize(Cross(T + horzDiff * N, B + vertDiff * N));

    // float epsilon = 0.0008f;

    // float referenceU = u < 1 - epsilon ? u + epsilon : u - epsilon;
    // float referenceV = v < 1 - epsilon ? v + epsilon : v - epsilon;

    // Vector3f textureColor = tex->RetrieveRGBFromUV(u, v);
    // Vector3f referenceTextureColor = tex->RetrieveRGBFromUV(referenceU, v);

    // float averageColorDU = (textureColor.x + textureColor.y + textureColor.z);
    // float averageReferenceDU = (referenceTextureColor.x + referenceTextureColor.y + referenceTextureColor.z);

    // float du = (averageReferenceDU - averageColorDU) / 6.0f * tex->bumpFactor;

    // referenceTextureColor = tex->RetrieveRGBFromUV(u, referenceV);
    // float averageColorDV = (textureColor.x + textureColor.y + textureColor.z);
    // float averageReferenceDV = (referenceTextureColor.x + referenceTextureColor.y + referenceTextureColor.z);
    // float dv = (averageReferenceDV - averageColorDV) / 6.0f * tex->bumpFactor;

    // Vector3f resultingPrime = Cross(T + du * N, B + dv * N);

    // if(Dot(resultingPrime, N) < 0)
    //     resultingPrime *= -1;

    // return resultingPrime;

    // Vector3f qpru = T + horzDiff * N;
    // Vector3f qprv = B + vertDiff * N;

    // Vector3f nnnn = N - T * horzDiff - B * vertDiff;
    // nnnn = Normalize(nnnn);
    // if (false && Scene::pScene->debugCurrent >= Scene::pScene->debugBegin && Scene::pScene->debugCurrent <= Scene::debugEnd)
    // {
    //     std::cout << " B U M P D U M P \n";
    //     std::cout << "Point: \n"
    //               << intersection.ip << "Original normal: " << intersection.n;
    //     std::cout << "Tangent: \n"
    //               << T << "Bitangent: \n"
    //               << B;
    //     std::cout << "Crossed normal: \n"
    //               << N;

    //     std::cout << "Color Values:\n";
    //     std::cout << "Self: " << self.x << "East: " << east.x << " West: " << west.x << " North: " << north.x << " South: " << south.x << "\n";
    //     std::cout << "Diff results: \n Horizontal Diff " << horzDiff << " Vertical diff: " << vertDiff << "\n";
    //     std::cout << "Resulting Normal: \n"
    //               << nnnn;

    //     system("pause");
    // }

    
    // if(Dot(nnnn, N) < 0)
    //     nnnn *= -1;

    

    // Vector3f nres = Normalize(Cross(qpru, qprv));


    


    // if(Dot(nres, intersection.n) < 0)
    //     nres *= -1;

    // return nres;


    // if (Dot(N, intersection.n))
    //     N *= -1;

    // Vector3f offset = tex->bumpFactor * (((north - self) - (south - self)) * T + ((east - self) - (west - self)) * B);

    // Vector3f D = (tex->bumpFactor / SqLength(N)) * ((east - west) * Cross(N, B) - (north - south) * Cross(N, T));


    // Vector3f ddd = N + D;
    // if(Dot(ddd, intersection.n) < 0)
    //     ddd *= -1;

    // //std::cout << offset;
    // Vector3f rrii =  N + offset;
    // if(Dot(rrii, intersection.n) < 0)
    //     rrii *= -1;


    // Vector3f diff1 = (tex->GetHorizontalDifference(intersection.uv.x, intersection.uv.y)) * tex->bumpFactor * 100;
    // Vector3f diff2 = (tex->GetVerticalDifference(intersection.uv.x, intersection.uv.y)) * tex->bumpFactor * 100;

    // Vector3f rsn = Normalize(Cross((Vector3f)T, (Vector3f)B));
    // if (Dot(rsn, intersection.n) < 0)
    //     rsn *= -1;

    // Vector3f qu = (Vector3f)T + diff1.x * intersection.n;
    // Vector3f qv = (Vector3f)B + diff2.y * intersection.n;

    // Vector3f ress = Normalize(Cross((Vector3f)B, (Vector3f)T));

    // ress = Normalize(tex->RetrieveRGBFromUV(intersection.uv.x, intersection.uv.y));


    // if(Dot(ress, intersection.n) < 0)
    //     ress *= -1.0f;

    // // ress = intersection.n;
    // // std::cout << "Old normal: " << ress;
    // Vector3f bumped = ress + (diff1 * (Cross(ress, (Vector3f)B)) - (diff2 * Cross(ress, (Vector3f)T))) / SqLength(ress);


    // if(Dot(bumped, intersection.n) < 0)
    //     bumped *= -1.0f;


    // int i1 = MaxAbsElementIndex(diff1);
    // int i2 = MaxAbsElementIndex(diff2);

    // Vector3f d1 = (tex->GetPixelOffset(u, v, 1, 0) - tex->GetPixelOffset(u, v, -1, 0)) * tex->bumpFactor;
    // Vector3f d2 = (tex->GetPixelOffset(u, v, 0, 1) - tex->GetPixelOffset(u, v, 0, -1)) * tex->bumpFactor;

    // // B = Cross(intersection.n, T);

    // T = Normalize(T);
    // B = Normalize(B);

    // N = Cross(T, B);
    // if(Dot(N, intersection.n) < 0)
    //     N *= -1.0f;

    // // T = T - N * Dot(T, N);
    // // B = B - Dot(B, N) * N - Dot(T, B) * T;
    // // std::cout << Dot(T, intersection.n) << " " << Dot(B, intersection.n) << " " << Dot(T, B) << "\n";

    // Vector3f f1 = diff1.x * T;
    // Vector3f f2 = diff2.y * B;

    // f1 = T * ((d1.x + d1.y + d1.z) / 3);
    // f2 = B * ((d2.x + d2.y + d2.z) / 3);

    // rsn = intersection.n;

    // // rsn = Cross((Vector3f)T, (Vector3f)B);

    // // if(Dot(rsn, intersection.n) < 0)
    // //     rsn *= -1.0f;

    // Vector3f nn = rsn - f1 - f2;

    // return nn;
}

Vector3f Triangle::RegulateNormal(Vector3f textureNormal, SurfaceIntersection &intersection)
{

    glm::vec3 e1 = p0p1;
    glm::vec3 e2 = p0p2;

    glm::mat3x2 E(glm::vec2(e1.x, e2.x), glm::vec2(e1.y, e2.y), glm::vec2(e1.z, e2.z));

    glm::vec2 a1 = glm::vec2(this->v0->uv.u - this->v1->uv.u, this->v0->uv.v - this->v1->uv.v);
    glm::vec2 a2 = glm::vec2(this->v0->uv.u - this->v2->uv.u, this->v0->uv.v - this->v2->uv.v);

    glm::mat2x2 A(glm::vec2(a1.x, a2.x), glm::vec2(a1.y, a2.y));

    A = glm::inverse(A);

    glm::mat3x2 soughtMat = A * E;

    glm::vec2 rr1 = soughtMat[0];
    glm::vec2 rr2 = soughtMat[1];
    glm::vec2 rr3 = soughtMat[2];

    glm::vec3 T = Normalize(Vector3f(rr1.x, rr2.x, rr3.x));
    glm::vec3 B = Normalize(Vector3f(rr1.y, rr2.y, rr3.y));

    glm::mat3x3 lastRegul(T, B, normal);

    Vector3f newNormal = lastRegul * textureNormal;

    //float f1 = lastRegul[0].x * textureNormal.x + lastRegul[1].x * textureNormal.y + lastRegul[2].x * textureNormal.z;
    //float f2 = lastRegul[0].y * textureNormal.x + lastRegul[1].y * textureNormal.y + lastRegul[2].y * textureNormal.z;
    //float f3 = lastRegul[0].z * textureNormal.x + lastRegul[1].z * textureNormal.y + lastRegul[2].z * textureNormal.z;
//
    //newNormal.x = f1;
    //newNormal.y = f2;
    //newNormal.z = f3;

    return Normalize(newNormal);
}

void Triangle::Intersect(Ray &rr, SurfaceIntersection &rt)
{
    Ray* r; // Ray to use in intersection test
    if (false && Scene::debugCurrent >= Scene::debugBegin && Scene::debugCurrent <= Scene::debugEnd && this->ownerMesh != this)
    {
        std::cout << "Before Transformation Ray Stats: --- \n"
                    << r->o
                    << r->d;
        std::cout << "Operating with transformation matrices: --- \n"
                    << "plain: " << this->objTransform->transformationMatrix
                    << "inv: " << this->objTransform->invTransformationMatrix;
    }

    Ray transformedRay;

    if(this->ownerMesh == this || !this->activeMotion) // Not owned by a mesh
    {
        if(this->activeMotion)
        {
            Vector3f motBlurToRay = this->motionBlur * rr.time;
            Transformation tr = Translation(-1, (glm::vec3)motBlurToRay);

            Transform lastTransform = (*this->objTransform)(tr);

            transformedRay = (lastTransform)(rr, false);

            r = &transformedRay;
        }
        else
        {
            transformedRay = (*this->objTransform)(rr, false);
            r = &transformedRay;
        }

    }
    else if (rr.transformedModes.find(this->ownerMesh) != rr.transformedModes.end()) // Sibling has transformed the ray before
    {
        r = (rr.transformedModes.at(this->ownerMesh));
    }
    else // First triangle in the mesh to transform the ray
    {
        Vector3f motBlurToRay = this->motionBlur * rr.time;
        Transformation tr = Translation(-1, (glm::vec3)motBlurToRay);

        Transform* trr = new Transform((*this->objTransform)(tr));

        Ray* resultingRay = new Ray((*trr)(rr, false));
        resultingRay->time = rr.time;
        resultingRay->currMat = rr.currMat;
        resultingRay->currShape = rr.currShape;

        rr.InsertRay(this->ownerMesh, resultingRay);
        rr.InsertTransform(this->ownerMesh, trr);

        r = (rr.transformedModes.at(this->ownerMesh));
    }

    if (false && Scene::debugCurrent >= Scene::debugBegin && Scene::debugCurrent <= Scene::debugEnd && this->ownerMesh != this)
    {
        std::cout << "After Transformation Ray Stats: --- \n"
                  << r->o
                  << r->d;
    }

    Vector3f r1 = {p0p1.x, p0p2.x, r->d.x};
    Vector3f r2 = {p0p1.y, p0p2.y, r->d.y};
    Vector3f r3 = {p0p1.z, p0p2.z, r->d.z};

    Vector3f p0ro = {v0->p.x - r->o.x, v0->p.y - r->o.y, v0->p.z - r->o.z}; // Precalculate commonly used vector

    float detM = r1.x * (r2.y * r3.z - r2.z * r3.y) + r2.x * (r1.z * r3.y - r1.y * r3.z) + r3.x * (r1.y * r2.z - r1.z * r2.y); // Main determinant

    // Close to zero ( NaN upon division )
    if(detM > -Scene::pScene->intTestEps && detM < Scene::pScene->intTestEps )
        return; // Default value no intersection

    // Use cramer's rule to solve for v1, v2 and t
    float invDetM = 1 / detM; // Calculate 1 / detM since it is faster for cpu to do multiplication

    r1.x = p0ro.x;
    r2.x = p0ro.y;
    r3.x = p0ro.z;

    float det1 = r1.x * (r2.y * r3.z - r2.z * r3.y) + r2.x * (r1.z * r3.y - r1.y * r3.z) + r3.x * (r1.y * r2.z - r1.z * r2.y);

    float v1 = det1 * invDetM; // beta val

    float err = 1 + Scene::pScene->intTestEps; // Calculate 1 + error rate once

    // Check bounds
    if(v1 < -Scene::pScene->intTestEps || v1 > err)
        return; // Default value no intersection

    r1.x = p0p1.x;
    r2.x = p0p1.y;
    r3.x = p0p1.z;

    r1.y = p0ro.x;
    r2.y = p0ro.y;
    r3.y = p0ro.z;

    float det2 = r1.x * (r2.y * r3.z - r2.z * r3.y) + r2.x * (r1.z * r3.y - r1.y * r3.z) + r3.x * (r1.y * r2.z - r1.z * r2.y);

    float v2 = det2 * invDetM; // gamma val

    // Check bounds
    if (v2 < -Scene::pScene->intTestEps || v2 > err || v1 + v2 > err)
        return; // Default value no intersection

    r1.y = p0p2.x;
    r2.y = p0p2.y;
    r3.y = p0p2.z;

    r1.z = p0ro.x;
    r2.z = p0ro.y;
    r3.z = p0ro.z;

    float det3 = r1.x * (r2.y * r3.z - r2.z * r3.y) + r2.x * (r1.z * r3.y - r1.y * r3.z) + r3.x * (r1.y * r2.z - r1.z * r2.y);

    float t = det3 * invDetM; // Derive t

    // Check if t value is in the front
    if (t >= -Scene::pScene->intTestEps)
    {
        // Transforming normal and intersection point mistake
        // not setting 1.0f at the end
        Vector3f po = (*r)(t); // Get intersection point using parameter t
        Vector3f normal = this->normal;

        Vector2f uv;
        Transform *trr = this->objTransform;
        uv = this->v0->uv * (err - v1 - v2) +
             this->v1->uv * v1 +
             this->v2->uv * v2;

        if(this->shadingMode == Shape::ShadingMode::SMOOTH)
        {
            normal = this->v0->n * (err - v1 - v2) +
                     this->v1->n * v1 +
                     this->v2->n * v2;

            normal = Normalize(normal);
        }

        // normal = (*trr)(Vector4f(normal, 0.0f), true, true); // !!!!!!!! was this->normal
        // normal = Normalize(normal);


        if(false && textures[1])
        {
            Vector2f uvA = this->v0->uv;
            Vector2f uvB = this->v1->uv;
            Vector2f uvC = this->v2->uv;

            float ubMinusUa = uvB.x - uvA.x;
            float vbMinusVa = uvB.y - uvA.y;
            float ucMinusUa = uvC.x - uvA.x;
            float vcMinusVa = uvC.y - uvA.y;

            float det = 1.f / (ubMinusUa * vcMinusVa - vbMinusVa * ucMinusUa);

            Vector3f pp0 = (*this->objTransform)(Vector4f(this->v0->p, 1.0f), true);
            Vector3f pp1 = (*this->objTransform)(Vector4f(this->v1->p, 1.0f), true);
            Vector3f pp2 = (*this->objTransform)(Vector4f(this->v2->p, 1.0f), true);

            pp0 = this->v0->p;
            pp1 = this->v1->p;
            pp2 = this->v2->p;


            Vector3f pU = (vcMinusVa * det) * (pp1 - pp0) + (-vbMinusVa * det) * (pp2 - pp0);
            Vector3f pV = (-ucMinusUa * det) * (pp1 - pp0) + (ubMinusUa * det) * (pp2 - pp0);

            float u = uvA.x + v1 * (uvB.x - uvA.x) + v2 * (uvC.x - uvA.x);
            float v = uvA.y + v1 * (uvB.y - uvA.y) + v2 * (uvC.y - uvA.y);

            u -= std::floor(u);
            v -= std::floor(v);

            pU = pU;
            pV = pV;
            // normal = textures[1]->GetBumpNormal(normal, u, v, pU, pV);
            // normal = Normalize(normal);

        }
        
        if(this->ownerMesh == this)
        {
            if(this->activeMotion)
            {
                Vector3f motBlurToRay = this->motionBlur * rr.time;
                Transformation tr = Translation(-1, (glm::vec3)motBlurToRay);

                Transform lastTransform = (*this->objTransform)(tr);
                trr = &lastTransform;
            }
            else
                trr = this->objTransform;
        }
        else
        {
            if(this->activeMotion)
            {
                trr = (rr.transformMatrices.at(this->ownerMesh));
            }
            else
            {
                trr = this->objTransform;
            }

        }


        Vector3f lip = po;
        // std::cout << "Local pos: " << textures[0]->RetrieveRGBFromUV(po.x, po.y, po.z);

        if(trr->transformationMatrix != glm::mat4(1))
        {
            po = (*trr)(Vector4f(po, 1.0f), true);
            normal = (*trr)(Vector4f(normal, 0.0f), true, true); // !!!!!!!! was this->normal
            normal = Normalize(normal); 
        }

        // std::cout << "World pos: " << textures[0]->RetrieveRGBFromUV(po.x, po.y, po.z);

        // system("pause");
        // if (Scene::debugCurrent >= Scene::debugBegin && Scene::debugCurrent <= Scene::debugEnd && this->ownerMesh != this)
        // {
        //     std::cout << "Pixel: " << Scene::debugCurrent << " tid: " << this->id << " Real t:" << rr(po) << "\n";
        //     std::cout << "Transformed Back To World Ray Stats: --- \n"
        //               << ((trr)(*r, true)).o
        //               << ((trr)(*r, true)).d;
        //     std::cout << "Value of t: \n" << t
        //               << "Ray Pos Found in World " << ((trr)(*r, true))(t)
        //               << "Original normal\n" <<  this->normal
        //               << "Transformed normal\n" << normal;
        //     std::cout << "Triangle id: " << this->id << "\n";
        //     std::cout << "Points: " << this->v0->p << this->v1->p << this->v2->p;
        //     //system("pause");
        // }


        t = rr(po);

        // po to r(t)

        rt = SurfaceIntersection(lip, po, normal, uv, Normalize(rr.o - po), t, this->mat, this, textures[0], textures[1]);
    }

}

Shape *Triangle::Clone(bool resetTransform) const
{
    Triangle* cloned = new Triangle{};
    cloned->shType = ShapeType::TRIANGLE;

    cloned->id = this->id;
    cloned->mat = this->mat;
    cloned->orgBbox = this->orgBbox;

    cloned->ownerMesh = cloned;

    for (Texture *t : this->textures)
        cloned->textures.push_back(t);

    if(!resetTransform)
    {
        cloned->bbox = this->bbox;
        Transform* newTransformation = new Transform(*(this->objTransform));
        cloned->objTransform = newTransformation;
    }
    else
    {
        cloned->bbox = this->orgBbox;
        glm::mat4 dummy = glm::mat4(1);
        cloned->objTransform = new Transform{dummy};
    }

    cloned->v0 = this->v0;
    cloned->v1 = this->v1;
    cloned->v2 = this->v2;

    cloned->p0p1 = this->p0p1;
    cloned->p0p2 = this->p0p2;

    cloned->normal = this->normal;

    return cloned;
}

}