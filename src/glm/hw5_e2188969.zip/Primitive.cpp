#include "Primitive.h"

namespace actracer {
    
}